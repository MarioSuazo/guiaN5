﻿using guiaN5;
using System;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;

public class Program
{
    public static void Main(string[] args)
    {
        List<Telefono> inventarioTel = new List<Telefono>();

        bool continuar = true;
        int opc;
        do
        {
            Console.WriteLine("Registro de Celulares:");
            Console.WriteLine("1. Registrar Telefono." +
                            "\n2. Mostrar Telefonos registrados." +
                            "\n3. Consultar Stock de un Telefono." +
                            "\n4. Salir.");

            opc = Convert.ToInt32(Console.ReadLine());

            switch (opc)
            {
                case 1:
                    registrarTelefono(inventarioTel);
                break;

                case 2:
                    mostrarTelefonosRegistrados(inventarioTel);
                break;

                case 3:
                    consultarStockTelefono(inventarioTel);
                break;

                case 4:
                    Console.WriteLine("Cerrando Programa.");
                break;

                default:
                    Console.WriteLine("Opción Inválida. Elija de nuevo:");
                break;
            }

        } while (opc == 4);

        static void registrarTelefono(List<Telefono> inventarioTel)
        {
            Console.WriteLine("Que Tipo de Celular Desea Registrar? (Inteligente(A)/Basico(B)):");
            string tipoTelefono = Console.ReadLine();

            if (tipoTelefono == "A")
            {
                TelefonoInteligente inteligente = new TelefonoInteligente();

                Console.Write("Marca: ");
                inteligente.marca = Console.ReadLine();

                Console.Write("Modelo: ");
                inteligente.modelo = Console.ReadLine();

                Console.Write("Precio: ");
                inteligente.precio = Convert.ToDouble(Console.ReadLine());

                Console.Write("Sistema Operativo: ");
                inteligente.sistemaOperativo = Console.ReadLine();

                Console.Write("Almacenamiento (en GB): ");
                inteligente.almacenamiento = Convert.ToInt32(Console.ReadLine());

                inventarioTel.Add(inteligente);

                Console.WriteLine("Se ingresó al inventario.");
            }
            else if (tipoTelefono == "B")
            {
                TelefonoBasico basico = new TelefonoBasico();

                Console.Write("Marca: ");
                basico.marca = Console.ReadLine();

                Console.Write("Modelo: ");
                basico.modelo = Console.ReadLine();

                Console.Write("Precio: ");
                basico.precio = Convert.ToDouble(Console.ReadLine());

                Console.Write("Tiene Linterna (true/false): ");
                basico.tieneLinterna = Convert.ToBoolean(Console.ReadLine());

                Console.Write("Tiene Radio Por Antena (true/false): ");
                basico.tieneRadioFM = Convert.ToBoolean(Console.ReadLine());

                inventarioTel.Add(basico);

                Console.WriteLine("Se ingresó en el inventario.");
            }
        }

        static void mostrarTelefonosRegistrados(IEnumerable<Telefono> inventarioTel)
        {
            Console.WriteLine("Celulares Registrados: ");

            //Creamos una estructura foreach para mostrar los celulares registrados 

            foreach (Telefono telefono in inventarioTel)
            {
                if (telefono is TelefonoInteligente)
                {
                    ((TelefonoInteligente)telefono).mostrarInfoInteligente();
                }
                else if (telefono is TelefonoBasico)
                {
                    ((TelefonoBasico)telefono).mostrarInfoBasico();
                }
            }
        }

        static void consultarStockTelefono(IEnumerable<Telefono> inventarioTel)
        {
            Console.WriteLine("Ingrese el modelo de celular a buscar: \n1. Inteligente\n2. Básico.");
            string modeloB = Console.ReadLine();
            bool existe = false;

            foreach (Telefono telefono in inventarioTel)
            {
                if (telefono.modelo == modeloB)
                {
                    existe = true;
                    if (telefono is TelefonoInteligente)
                    {
                        ((TelefonoInteligente)telefono).mostrarInfoInteligente();
                    }
                    else if (telefono is TelefonoBasico)
                    {
                        ((TelefonoBasico)telefono).mostrarInfoBasico();
                    }
                }
            }

            if (!existe)
            {
                Console.WriteLine("Celular no encontrado.");
            }
        }
    }
}