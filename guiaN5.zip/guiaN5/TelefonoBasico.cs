﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace guiaN5
{
    internal class TelefonoBasico : Telefono
    {
        public bool tieneRadioFM { get; set; }
        public bool tieneLinterna { get; set; }
        public bool tieneCulebrita { get; set; }

        public void mostrarInfoBasico()
        {
            mostrarInfoTelefono();
            Console.WriteLine($"Tiene Radio FM: {tieneRadioFM}, Tiene Linterna: {tieneLinterna}, Tiene la Culebrita: {tieneCulebrita}");
        }
    }
}
