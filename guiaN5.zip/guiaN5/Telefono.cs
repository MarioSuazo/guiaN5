﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace guiaN5
{
    internal class Telefono
    {
        public string marca { get; set; }
        public string modelo { get; set; }
        public double precio { get; set; }
        public double stock { get; set; }

        public void mostrarInfoTelefono()
        {
            Console.WriteLine($"Marca: {marca}, Modelo: {modelo}, Precio {precio}, Stock: {stock}");
        }
    }
}
