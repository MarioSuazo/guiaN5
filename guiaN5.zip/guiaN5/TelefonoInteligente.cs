﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace guiaN5
{
    internal class TelefonoInteligente : Telefono
    {
        public string sistemaOperativo { get; set; }
        public int memoria { get; set; }
        public int almacenamiento { get; set; }
        public void mostrarInfoInteligente()
        {
            mostrarInfoTelefono();
            Console.WriteLine($"Sistema operativo: {sistemaOperativo}, Memoria: {memoria}GB, Almacenamiento: {almacenamiento}");
        }
    }
}
